#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Simple FC Info message emulator
"""

import serial
import sys
from ConfigParser import ConfigParser

if __name__ == "__main__":
    config = ConfigParser()
    try:
        config.read('fclogger.cfg')
        port = config.get('emulator', 'port')
        baud = config.getint('emulator', 'baud')
        interval = config.getint('emulator', 'interval')
    except:
        print("Configuration file: fclogger.cfg not found or invalid")
        sys.exit(-1)
    print("Simple FC Info message emulator (Ctrl-C to exit)")
    print("Waiting for request...")
    port = serial.Serial(port, baudrate=baud, timeout=interval/1000.0, parity=serial.PARITY_EVEN, rtscts=True)
    try:
        while True:
            rv = port.read(1)
            if len(rv) > 0:
                for c in rv:
                    print "0x%02X" % ord(c),
                    if ord(c) == 0x0D:
                        print "\nSending reply FC info..."
                        port.write('\xf0\x20')
                        for i in range(0, 0x20 - 1):
                            port.write(chr(i))
                        print("Waiting for request...")

    except:
        print("Exit!!!")
        