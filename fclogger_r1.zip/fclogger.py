#!/usr/bin/env python
# -*- coding: utf-8 -*-

import serial
import time
import sys
import os
import logging
from datetime import datetime
from ConfigParser import ConfigParser
from struct import unpack_from

__version__ = 'r1 (2013/12/05)'
__filename__ = os.path.splitext(os.path.basename(__file__))[0]

class FCLogger:
    """ FC Logger class
    """
    FC_ADV_INFO_LEN = 0x20
    FC_REQ_ADV_INFO = '\xF0\x02\x0D'
    FC_ADV_INFO_KEYS = ['Engine Speed(rpm)',
                        'Absolute Intake Pressure(Kg/cm^2)',
                        'Pressure Sensor Voltage(mV)',
                        'Throttle Voltage(mV)',
                        'Primary Injector Pulse Width(mSec)',
                        'Fuel Correction',
                        'Leading Ignition Angle(deg)',
                        'Trailing Ignition Angle(deg)',
                        'Fuel Temperature(deg.C)',
                        'Metalling Oil PumpDuty(%)',
                        'Boost Duty(Tp, %)',
                        'Boost Duty(Wg, %)',
                        'Water Temperature(deg.C)',
                        'Intake Air Temperature(deg.C)',
                        'Knocking Level',
                        'Battery Voltage(V)',
                        'Vehicle Speed(Km/h)',
                        'ISCV duty(%)',
                        'O2 Sensor Voltage(mV)',
                        'N/A',
                        'Secondary Injector Pulse Width(mSec)',
                        'N/A']
    FC_ADV_INFO_MUL = [1, 0.0001, 1, 1, 1.0/256, 1.0/256, 1, 1, 1, 212.0/256, 0.4, 0.4, 1, 1, 1, 0.1, 1, 0.1, 0.02, 1, 1.0/256, 1]
    FC_ADV_INFO_ADD = [0, 0, 0, 0, 0, 0, -25, -25, -80, 0, 0, 0, -80, -80, 0, 0, 0, 0, 0, 0, 0, 0]
    
    def __init__(self, portName, baudRate, interval=200):
        self.portName = portName
        self.port = serial.Serial(self.portName, baudrate=baudRate, timeout=interval/1000.0, parity=serial.PARITY_EVEN, rtscts=True)
        self.interval = interval/1000.0
        
    def close(self):
        self.port.close()
    
    def write(self, buf):
        logging.debug("Write(%d): %s" % (len(buf), str2hex(buf)))
        self.port.write(buf)
        
    def read(self, length):
        buf = self.port.read(length)
        logging.debug("Read(%d/%d): %s" % (len(buf), length, str2hex(buf)))
        return buf
            
    def getInfo(self, ilen=FC_ADV_INFO_LEN):
        self.write(self.FC_REQ_ADV_INFO)
        return self.read(ilen + 1)
        
    def getInfoLength(self):
        buf = self.getInfo()
        if len(buf) >= (self.FC_ADV_INFO_LEN + 1):
            return ord(buf[1])
        else:
            return -1
    
    def decode(self, buf):
        try:
            out = unpack_from('<HHHHHHBBBBBBBBBBHHBBHB', buf, offset=2)
            out = [a * b for a, b in zip(out, self.FC_ADV_INFO_MUL)]
            out = [a + b for a, b in zip(out, self.FC_ADV_INFO_ADD)]
            info = dict(zip(self.FC_ADV_INFO_KEYS, out))
        except Exception as ex:
            logging.error(ex)
            return None
        return info
        
    def run(self):
        try:
            ilen = -1
            while ilen == -1:
                ilen = self.getInfoLength()
                logging.debug("Get Info length = %d" % (ilen))
                time.sleep(1)
            logging.info("Info length = %d" % (ilen))
            while True:
                buf = self.getInfo(ilen) 
                info = self.decode(buf)
                if info == None:
                    logging.warn("Cannot decode info buffer")
                    continue
                print("-"*60)
                logging.info("%-40s %s" % ("Time", datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                for k in self.FC_ADV_INFO_KEYS:
                    if k != "N/A":
                        logging.info("%-40s %s" % (k, info[k]))
                time.sleep(self.interval)
        except KeyboardInterrupt:
            logging.info("Exit...")
            self.close()

def str2hex(buf):
    """ Convert string buffer to hexadecimal
    """
    if len(buf):
        return " ".join([ "%02X" % ord(ch) for ch in buf ])
    else:
        return ""

def setup_logger():
    """ Set up logging
    """
    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(levelname)-8s %(message)s',
                        datefmt='%m-%d %H:%M',
                        filename='%s.log' % __filename__,
                        filemode='a')
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)
    
if __name__ == '__main__':
    setup_logger()
    logging.info("%s - %s" % (__filename__, __version__))    
    config = ConfigParser()
    try:
        config.read('%s.cfg' % __filename__)
        port = config.get('default', 'port')
        baud = config.getint('default', 'baud')
        interval = config.getint('default', 'interval')
    except:
        logging.error("Configuration file: %s.cfg not found or invalid" % (__filename__))
        sys.exit(-1)
    logging.info("Config port = %s, baud = %d, interval = %d" % (port, baud, interval))
    fc = FCLogger(port, baud, interval)
    fc.run()